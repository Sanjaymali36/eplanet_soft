from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import authentication, permissions
from django.contrib.auth.models import User
from rest_framework.decorators import api_view
from .scrapper import scrapper






from .serializers import ScraperSerializer


@api_view()
def scrapping(request,country):
    d=scrapper(country)
    s=ScraperSerializer(d)
    return Response(s.data)


































print()