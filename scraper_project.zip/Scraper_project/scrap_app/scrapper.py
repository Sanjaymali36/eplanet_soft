from bs4 import BeautifulSoup
import requests

scrapdata = {}
def scrapper(country_name):
    path = 'https://en.wikipedia.org/wiki/{}'.format(country_name)
    html = requests.get(path)
    content=html.content
    soup = BeautifulSoup(content, "html.parser")
    all_data = soup.find_all("table", {"class": "infobox ib-country vcard"})
    for x in all_data:
        try:
            scrapdata['flag_link'] = "https:"+x.find('img')['src']
        except:
            scrapdata['flag_link'] = " "
        try:
            all_capitals = x.find_all('td',{'class': 'infobox-data'})
            for i in all_capitals[:1]:
                cap=i.contents[0].text.split('[')[0]
                #print('sanjayyyyyy',cap)
                scrapdata['capital'] =[cap]

        except:
            scrapdata['capital']=''
        try:
            largest_cities= x.find("div", attrs={'class': 'plainlist'})
            lc=largest_cities.find_all('a')
            all_largest_cities=[]
            for i in lc:
                #print('largest cities data', i.get_text().strip())
                all_largest_cities.append(i.get_text().strip())
            scrapdata['largest_city'] =all_largest_cities
        except:
            scrapdata['largest_city'] = ""
        try:
            official_langauges= x.find("div",attrs= {'class': 'hlist hlist-separated'})
            lang=official_langauges.find_all('a')
            all_languages = []
            for i in lang:
                #print('lang data', i.get_text().strip())
                all_languages.append(i.get_text().strip())
            scrapdata['official_languages'] = all_languages[:2]
        except:
            scrapdata['official_languages'] = " "
        try:
            population=x.find("td", {'class': 'infobox-data'})[22]
            population=population.text
            scrapdata['population'] = population

        except:
            scrapdata['population'] = " "


        try:
            area = x.find_all("td",{'class': 'infobox-data'})[19]
            scrapdata['area_total'] = area.text


        except:
            scrapdata['area_total'] = " "
        try:
            gdp_nominal = x.find_all("span", {'class': 'nowrap'})[2]
            for gdp in gdp_nominal:
                scrapdata['gdp_nominal'] =gdp
        except:
            scrapdata['gdp_nominal'] = " "

    return scrapdata

