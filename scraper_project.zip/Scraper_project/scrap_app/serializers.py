
from rest_framework import serializers

#SANJAY
class ScraperSerializer(serializers.Serializer):
    flag_link=serializers.CharField()
    capital=serializers.ListField()

    largest_city=serializers.CharField()
    official_languages=serializers.ListField()

    area_total=serializers.CharField(max_length=100)
    population=serializers.CharField(max_length=100)
    gdp_nominal=serializers.CharField(max_length=100)



